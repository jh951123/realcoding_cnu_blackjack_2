package com.cnu.blackjack.exceptions;

public class NotEveyonePlacedBetException extends RuntimeException {
}
