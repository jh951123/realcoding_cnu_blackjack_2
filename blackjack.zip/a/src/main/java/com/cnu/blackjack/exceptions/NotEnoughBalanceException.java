package com.cnu.blackjack.exceptions;

public class NotEnoughBalanceException extends RuntimeException {
}
